package effectivejava.chapter3.item13;

public class EmptyStackException extends IllegalStateException {
}
