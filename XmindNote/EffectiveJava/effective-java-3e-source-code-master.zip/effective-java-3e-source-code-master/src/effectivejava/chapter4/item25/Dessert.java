package effectivejava.chapter4.item25;

// Two classes defined in one file. Don't ever do this! (Page 115)
//class Utensil {
//    static final String NAME = "pot";
//}
//
//class Dessert {
//    static final String NAME = "pie";
//}