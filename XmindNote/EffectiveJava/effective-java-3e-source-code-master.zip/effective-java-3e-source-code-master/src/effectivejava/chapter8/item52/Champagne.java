package effectivejava.chapter8.item52;

// Classification using method overrriding (Page 239)
class Champagne extends SparklingWine {
    @Override String name() { return "champagne"; }
}
