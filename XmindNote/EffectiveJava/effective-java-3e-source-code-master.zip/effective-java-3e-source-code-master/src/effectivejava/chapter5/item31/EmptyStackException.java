package effectivejava.chapter5.item31;

public class EmptyStackException extends RuntimeException {
}
